using System.Collections.Generic;

namespace SharePlatformSystem.Domain.Uow
{
    public class ConnectionStringResolveArgs : Dictionary<string, object>
    {
      
    }
}