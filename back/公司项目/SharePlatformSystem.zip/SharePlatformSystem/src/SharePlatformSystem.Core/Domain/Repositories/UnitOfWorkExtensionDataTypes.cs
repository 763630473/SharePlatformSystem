﻿namespace SharePlatformSystem.Core.Domain.Repositories
{
    internal class UnitOfWorkExtensionDataTypes
    {
        public static string HardDelete { get; } = "HardDelete";
    }
}
