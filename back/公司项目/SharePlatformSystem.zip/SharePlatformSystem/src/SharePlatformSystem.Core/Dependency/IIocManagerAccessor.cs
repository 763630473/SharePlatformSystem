namespace SharePlatformSystem.Dependency
{
    public interface IIocManagerAccessor
    {
        IIocManager IocManager { get; }
    }
}