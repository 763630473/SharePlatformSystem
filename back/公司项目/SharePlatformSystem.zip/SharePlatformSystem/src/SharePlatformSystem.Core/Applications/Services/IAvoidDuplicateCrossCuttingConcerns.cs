﻿using System.Collections.Generic;

namespace SharePlatformSystem.Applications.Services
{
    public interface IAvoidDuplicateCrossCuttingConcerns
    {
        List<string> AppliedCrossCuttingConcerns { get; }
    }
}