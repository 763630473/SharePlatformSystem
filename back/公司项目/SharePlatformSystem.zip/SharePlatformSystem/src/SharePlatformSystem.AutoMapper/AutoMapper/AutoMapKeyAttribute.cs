﻿using System;
using AutoMapper;

namespace SharePlatformSystem.AutoMapper
{
    public class AutoMapKeyAttribute : Attribute
    {

    }
}