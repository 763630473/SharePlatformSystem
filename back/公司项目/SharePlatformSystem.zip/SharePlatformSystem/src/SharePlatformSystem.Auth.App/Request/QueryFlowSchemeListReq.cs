﻿namespace SharePlatformSystem.Auth.App.Request
{
    public class QueryFlowSchemeListReq : PageReq
    {
        public string orgId { get; set; }
    }
}
