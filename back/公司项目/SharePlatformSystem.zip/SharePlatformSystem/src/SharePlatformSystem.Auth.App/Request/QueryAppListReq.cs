﻿namespace SharePlatformSystem.Auth.App.Request
{
    public class QueryAppListReq : PageReq
    {

    }
}
