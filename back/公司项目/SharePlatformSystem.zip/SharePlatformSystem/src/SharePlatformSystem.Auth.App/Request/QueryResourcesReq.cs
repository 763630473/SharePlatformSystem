﻿namespace SharePlatformSystem.Auth.App.Request
{
    public class QueryResourcesReq : PageReq
    {
        /// <summary>
        /// TypeID
        /// </summary>
        public string appId { get; set; }

    }
}
