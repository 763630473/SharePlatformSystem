﻿namespace SharePlatformSystem.Auth.App.Request
{
    public class QueryUserListReq : PageReq
    {
        public string orgId { get; set; }
    }
}
