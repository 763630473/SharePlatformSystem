﻿namespace SharePlatformSystem.Auth.App.Request
{
    public class IdPageReq :PageReq
    {
        public string id { get; set; }
    }
}
